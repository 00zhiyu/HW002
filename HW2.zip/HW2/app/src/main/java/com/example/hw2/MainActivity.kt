package com.example.hw2


import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.hw2.ui.theme.HW2Theme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HW2Theme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    MyApp()
                }
            }
        }
    }
}

@Composable
fun MyApp() {
    AlignExample()
    val places = listOf(
        "台北101", "花蓮清水斷崖", "台中歌劇院", "台南林百貨", "台南赤崁樓", "台東伯朗大道", "鹿港天后宮", "花蓮蘇花公路"
    )
    val images = listOf(
        R.drawable.image1__1_,
        R.drawable.image3__1_,
        R.drawable.image4,
        R.drawable.image5,
        R.drawable.image6,
        R.drawable.image7,
        R.drawable.image8,
        R.drawable.image9
    )
    var currentIndexState by remember { mutableStateOf(-1) }

    if (currentIndexState == -1) {
        PlaceList(places) { index ->
            currentIndexState = index
        }
    } else {
        PlaceDetailScreen(
            placeName = places[currentIndexState],
            imageRes = images[currentIndexState],
            onBack = { currentIndexState = -1 }
        )
    }
}


@Composable
fun PlaceList(places: List<String>, onItemClick: (Int) -> Unit) {
    LazyColumn {
        items(places) { place ->
            val index = places.indexOf(place)
            if (index != -1) {
                PlaceItem(place, index, onItemClick)
            }
        }
    }
}

@Composable
fun PlaceItem(place: String, index: Int, onItemClick: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick(index) }
            .padding(16.dp)
    ) {
        Text(text = place)
    }
}

@Composable
fun PlaceDetailScreen(placeName: String, imageRes: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = placeName,
                modifier = Modifier.fillMaxSize()
            )
        }
        Text(
            text = placeName,
            modifier = Modifier.padding(16.dp)
        )
        Text(
            text = "詳細位置",
            modifier = Modifier
                .padding(16.dp)
                .clickable {
                    val gmmIntentUri = Uri.parse("geo:0,0?q=$placeName")
                    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                    mapIntent.setPackage("com.google.android.apps.maps")
                    context.startActivity(mapIntent)
                }
        )
        Spacer(modifier = Modifier.height(8.dp))
    }
    Text(
        text = "上一頁",
        modifier = Modifier
            .padding(16.dp)
            .clickable { onBack() }
    )
}


@Composable
fun AlignExample() {
    Box(modifier = Modifier.size(100.dp)) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .align(Alignment.TopStart)
                .background(Color.Red)
        )
    }
}
